<?php
    define('TEMPLATES_URL', __DIR__.'\\templates');
    define('FUNCIONES_URL', __DIR__.'funciones.php');
?>